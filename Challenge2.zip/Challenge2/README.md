# Problem statement

1. Script expects one user argument[ARG].
2. User input with 'all', script will fetch all the metadata of an aws instance.
3. User input with any specific key from metadata, script will fetch key and value both.
4. User input with any specific key and value from metadata, script will validate the key-value. if Key-value present it will show in the output, else it will return null.


## Limitation
 Script will expect one instance to present. 

# Prereq's

 1. Linux with perl & AWS CLI <link>
 2. AWS linux instances will have all pre-reqs- inbuilt.
 3. User has to provide "aws configure --profile cliuser" and follow the command instructions for access keys and secrets

