#!/bin/perl

my $all_instances = `aws ec2 describe-instances --profile cliuser`;
chomp($all_instances);
my $choice = $ARGV[0];
my ($filter, $value) = split /=/,$choice;

if($#ARGV != 0){
        print("Please enter one argument \"all\" or the Filter value\n");
        print("Program exiting...\n");
        exit();
}
elsif(($filter eq 'all') && ($value eq '')) {
        print($all_instances);
}
elsif(($filter ne 'all') && ($value eq '')){
        my $all_instances = `aws ec2 describe-instances --profile cliuser --query \"Reservations[*].Instances[*].$filter\" --output json`;
        chomp($all_instances);
                print($all_instances);
        }
}
elsif(($filter ne 'all') && ($value ne '')){
        my $all_instances = `aws ec2 describe-instances --profile cliuser --query \"Reservations[*].Instances[*].$filter\" --output json`;
        chomp($all_instances);
        if($all_instances =~ $value) {
                print($all_instances);
        }
}
else{}