# Terraform code to deploy three-tier architecture in azure with App Gateway using Paas Services.

## Three-tier architecture?
Three-tier architecture is a software application architecture that organizes applications into three tiers: Web Tier, App Tier and the data tier where the data associated with the application is stored and managed.

## What is terraform?
Terraform is an open-source infrastructure as code software tool created by HashiCorp. Users define and provision data center infrastructure using a declarative configuration language known as HashiCorp Configuration Language, or optionally JSON.

## Installation
- [Terraform](https://www.terraform.io/downloads.html)

## Problem Statement

1. Public IP Resource: Used by the front end entry point. DNS entry to be created manually which is out of scope of Terraform IAC
2. Azure Application gateway resource and configuration: It is the landing point for all external users to access the web appliation securely.
3. Web Tier :Host the website landing page.
4. App Tier :Host the application logic and connect to data tier.
5. Data Tier: logical database management entity that defines all of the SQL Server objects.
6. Web  can connect only to App, App can connect to database but database cannot connect to web.
7. One virtual network tied in two subnets (Front end and backend).


### The Terraform resources will consists of following structure

******
├── main.tf               // The primary entrypoint for terraform resources.
├── public-ip.tf          // Public IP resource for frontend access.
├── app-gateway.tf        // Application gateway configuration with rules.
├── web.tf                // web tier 
├── app.tf                 // app tier
├── db.tf                  // data Tier
├── network.tf              // Vnet with 2 subnet resources
├── output.tf              // It contain the declarations for outputs.
├── variables.tf          // It contain the declarations for variables.
├── locals.tf          // It contain the declarations for tags.
******


## Deployment Steps

1. `terraform init`

used to initialize a working directory containing Terraform configuration files

2.  `terraform plan`

used to create an execution plan to achieve desired state

3. `terraform validate`

validates the configuration files 

4. `terraform apply`

 apply the changes required to reach the desired state of the configuration


