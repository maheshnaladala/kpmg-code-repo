
# new = {
#   "john": {
#     "age": 27
#   },
#   "meg": {
#     "age": 44
#   }
# }
import json

def getValue(nestObjs, keys):
    count = 0
    keyList = keys.split('/')
    size = len(keyList)
    keyVals = nestObjs.keys()
    for k in keyVals:
        if keyList[count] == k:
            objNew = nestObjs[k]
            nextObject(objNew, count, keyList)


def nextObject(obj, count, keyList):
    count += 1
    if type(obj) is dict:
        keyVals = obj.keys()
        for k in keyVals:
            if keyList[count] == k:
                objNew = obj[k]
                nextObject(objNew, count, keyList)
    else:
        print('Value : ',obj)
                


objStr = input('Enter nested object : ')
dictObj = json.loads(objStr)
inpkeys = input('Enter keys : ')

getValue(dictObj, inpkeys)